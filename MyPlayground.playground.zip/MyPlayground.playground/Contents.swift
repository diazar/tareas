//: Playground - noun: a place where people can play

import UIKit

for i in 1...100{
    if ( i % 5 == 0 ){
        print("\(i)\tBingo!!!")
    }
    
    if ( i % 2 == 0 ){
      print("\(i)\tpar!!!")
    }
    else{
        
     print("\(i)\timpar!!!")
    }
    // even
    switch(i){
        case 30...40:
        
        print("Viva Swift!!!");
        break;
    default:
        break;
        
    }
    
}
