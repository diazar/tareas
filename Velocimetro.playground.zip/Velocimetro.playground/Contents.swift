//: Playground - noun: a place where people can play

import UIKit


enum Velocidades:Int{
    case Apagado = 0, Baja = 20, Media = 50, Alta = 120
    init(velocidadInicial:Velocidades){
        self = velocidadInicial
    }
    
}

class Auto {
    var velocidad:Velocidades
    init(){
        velocidad = Velocidades(velocidadInicial: .Apagado)
    }
    
    func cambioDeVelocidad() -> ( actual : Int, velocidadEnCadena: String){
        var frase = ""
        let velocidadactual = velocidad.rawValue
        switch velocidad {
        case .Apagado:
            velocidad = .Baja
            frase = "Apagado"
        case .Baja:
            velocidad = .Media
            frase = "Baja"
        case .Media:
            velocidad = .Alta
            frase = "Media"
        case .Alta:
            velocidad = .Apagado
            frase = "Alta"
        }
        return (velocidadactual, frase)
    }
    
}

var auto = Auto()
var i:Int = 0;
var vel="Velocidad";
for v in 1...20 {
    let result = auto.cambioDeVelocidad()
    print("\(v). \(vel) \(result.actual), \(result.velocidadEnCadena)")
}
